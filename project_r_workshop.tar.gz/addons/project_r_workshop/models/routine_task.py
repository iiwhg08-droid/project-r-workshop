# -*- coding: utf-8 -*-
"""مهام الورشة الدورية — يومية وأسبوعية وشهرية.

الفكرة: تعرّف المهمة مرة وحدة (قالب) وتقول كل كم تتكرر، والنظام يولّد
لك «تنفيذ» لكل دورة بتاريخ استحقاق. الموظف يأشّر «تمت»، وأنت تشوف
المتأخر والمنجز بدون ما تتذكر شي.
"""
from datetime import timedelta

from odoo import api, fields, models
from odoo.exceptions import UserError

FREQUENCIES = [
    ("daily", "يومية"),
    ("weekly", "أسبوعية"),
    ("monthly", "شهرية"),
    ("quarterly", "كل 3 شهور"),
    ("yearly", "سنوية"),
]

MONTHS = [
    ("1", "يناير"), ("2", "فبراير"), ("3", "مارس"), ("4", "أبريل"),
    ("5", "مايو"), ("6", "يونيو"), ("7", "يوليو"), ("8", "أغسطس"),
    ("9", "سبتمبر"), ("10", "أكتوبر"), ("11", "نوفمبر"), ("12", "ديسمبر"),
]

WEEKDAYS = [
    ("0", "الإثنين"), ("1", "الثلاثاء"), ("2", "الأربعاء"),
    ("3", "الخميس"), ("4", "الجمعة"), ("5", "السبت"), ("6", "الأحد"),
]


class PrRoutineTask(models.Model):
    _name = "pr.routine.task"
    _description = "مهمة دورية في الورشة"
    _inherit = ["mail.thread"]
    _order = "frequency, sequence, id"

    name = fields.Char(string="المهمة", required=True, tracking=True)
    sequence = fields.Integer(string="الترتيب", default=10)
    active = fields.Boolean(string="نشطة", default=True)
    description = fields.Text(
        string="التفاصيل",
        help="وش المطلوب بالضبط — يقرأها الموظف وقت التنفيذ.",
    )
    frequency = fields.Selection(
        FREQUENCIES, string="التكرار", required=True, default="daily",
        tracking=True, group_expand="_group_expand_frequency",
    )
    weekday = fields.Selection(
        WEEKDAYS, string="يوم الأسبوع", default="5",
        help="للمهام الأسبوعية — أي يوم تستحق فيه.",
    )
    month_day = fields.Integer(
        string="يوم الشهر", default=1,
        help="للمهام الشهرية والربعية والسنوية — أي يوم من الشهر تستحق فيه (1 إلى 28).",
    )
    anchor_month = fields.Selection(
        MONTHS, string="شهر البداية", default="1",
        help="للمهام كل 3 شهور: أول شهر تستحق فيه، ثم كل 3 شهور بعده. "
             "وللسنوية: الشهر الذي تستحق فيه كل سنة.",
    )
    department_id = fields.Many2one("pr.department", string="القسم")
    user_id = fields.Many2one(
        "res.users", string="المسؤول",
        help="اتركه فارغاً لو المهمة على أي أحد موجود.",
    )
    company_id = fields.Many2one(
        "res.company", string="الشركة", required=True,
        default=lambda self: self.env.company,
    )

    occurrence_ids = fields.One2many(
        "pr.task.occurrence", "task_id", string="سجل التنفيذ",
    )
    open_count = fields.Integer(
        string="مفتوحة", compute="_compute_stats",
    )
    late_count = fields.Integer(
        string="متأخرة", compute="_compute_stats", search="_search_late_count",
    )
    last_done_date = fields.Date(
        string="آخر تنفيذ", compute="_compute_stats",
    )

    @api.model
    def _group_expand_frequency(self, values, domain):
        return [f[0] for f in FREQUENCIES]

    @api.depends("occurrence_ids.state", "occurrence_ids.due_date")
    def _compute_stats(self):
        today = fields.Date.context_today(self)
        for task in self:
            occ = task.occurrence_ids
            openo = occ.filtered(lambda o: o.state == "todo")
            task.open_count = len(openo)
            task.late_count = len(openo.filtered(lambda o: o.due_date and o.due_date < today))
            done = occ.filtered(lambda o: o.state == "done" and o.done_date)
            task.last_done_date = max(done.mapped("done_date")) if done else False

    def _search_late_count(self, operator, value):
        """يسمح بالفلترة على «فيها متأخر» رغم أن الحقل محسوب غير مخزّن."""
        today = fields.Date.context_today(self)
        late_tasks = self.env["pr.task.occurrence"].search([
            ("state", "=", "todo"), ("due_date", "<", today),
        ]).mapped("task_id")
        ids = late_tasks.ids
        has_late = None
        if operator in (">", ">=") and (value or 0) <= 0 and operator == ">=":
            return []
        if operator in (">", ">="):
            has_late = True
        elif operator in ("=", "=="):
            has_late = bool(value)
        elif operator in ("!=",):
            has_late = not bool(value)
        elif operator in ("<", "<="):
            has_late = False
        else:
            raise ValueError("عملية بحث غير مدعومة: %s" % operator)
        return [("id", "in" if has_late else "not in", ids)]

    @api.constrains("month_day")
    def _check_month_day(self):
        for task in self:
            if task.frequency in ("monthly", "quarterly", "yearly") \
                    and not (1 <= task.month_day <= 28):
                raise UserError(
                    "يوم الشهر لازم يكون بين 1 و 28 — عشان المهمة تستحق "
                    "في كل شهر بما فيها فبراير."
                )

    # ------------------------------------------------------------------
    # توليد التنفيذات
    # ------------------------------------------------------------------
    def _month_step(self):
        """كم شهراً بين استحقاق والذي يليه."""
        self.ensure_one()
        return {"monthly": 1, "quarterly": 3, "yearly": 12}.get(self.frequency, 1)

    def _next_due_date(self, from_date):
        """أول تاريخ استحقاق للمهمة يوم from_date أو بعده."""
        self.ensure_one()
        if self.frequency == "daily":
            return from_date
        if self.frequency == "weekly":
            target = int(self.weekday or "5")
            delta = (target - from_date.weekday()) % 7
            return from_date + timedelta(days=delta)

        day = min(max(self.month_day or 1, 1), 28)
        step = self._month_step()
        anchor = int(self.anchor_month or "1") if step > 1 else 1

        year, month = from_date.year, from_date.month
        # نبحث عن أول شهر يوافق الدورة ويكون تاريخه لسه ما فات
        for _ in range(36):
            if step == 1 or (month - anchor) % step == 0:
                if not (year == from_date.year and month == from_date.month
                        and from_date.day > day):
                    return from_date.replace(year=year, month=month, day=day)
            month += 1
            if month > 12:
                year, month = year + 1, 1
        return from_date.replace(day=day)

    def _generate_occurrences(self, horizon_days=14):
        """ينشئ التنفيذات المستحقة من اليوم وحتى الأفق المحدد."""
        Occurrence = self.env["pr.task.occurrence"]
        today = fields.Date.context_today(self)
        horizon = today + timedelta(days=horizon_days)
        created = Occurrence.browse()
        for task in self:
            due = task._next_due_date(today)
            while due <= horizon:
                exists = Occurrence.search_count([
                    ("task_id", "=", task.id), ("due_date", "=", due),
                ])
                if not exists:
                    created |= Occurrence.create({
                        "task_id": task.id,
                        "due_date": due,
                        "user_id": task.user_id.id or False,
                    })
                if task.frequency == "daily":
                    due = due + timedelta(days=1)
                elif task.frequency == "weekly":
                    due = due + timedelta(days=7)
                else:
                    due = task._next_due_date(due + timedelta(days=1))
        return created

    @api.model
    def cron_generate_occurrences(self):
        tasks = self.search([])
        created = tasks._generate_occurrences()
        return len(created)

    def action_generate_now(self):
        created = self._generate_occurrences()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": "تم التوليد",
                "message": "أُنشئت %d مهمة مستحقة." % len(created),
                "type": "success",
                "sticky": False,
            },
        }

    def action_open_occurrences(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "تنفيذ: %s" % self.name,
            "res_model": "pr.task.occurrence",
            "view_mode": "list,form",
            "domain": [("task_id", "=", self.id)],
            "context": {"default_task_id": self.id},
        }


class PrTaskOccurrence(models.Model):
    _name = "pr.task.occurrence"
    _description = "تنفيذ مهمة دورية"
    _inherit = ["mail.thread"]
    _order = "due_date desc, id desc"

    task_id = fields.Many2one(
        "pr.routine.task", string="المهمة", required=True,
        ondelete="cascade", index=True,
    )
    name = fields.Char(related="task_id.name", store=True, string="اسم المهمة")
    frequency = fields.Selection(
        related="task_id.frequency", store=True, string="التكرار",
        group_expand="_group_expand_frequency",
    )
    department_id = fields.Many2one(
        related="task_id.department_id", store=True, string="القسم",
    )
    company_id = fields.Many2one(
        related="task_id.company_id", store=True, string="الشركة",
    )
    due_date = fields.Date(string="تاريخ الاستحقاق", required=True, index=True)
    user_id = fields.Many2one("res.users", string="المسؤول", tracking=True)
    state = fields.Selection(
        [("todo", "مطلوبة"), ("done", "تمت"), ("skipped", "متجاوَزة")],
        string="الحالة", default="todo", required=True, tracking=True,
        index=True, group_expand="_group_expand_state",
    )
    done_by_id = fields.Many2one("res.users", string="نفّذها", readonly=True)
    done_date = fields.Date(string="تاريخ التنفيذ", readonly=True)
    note = fields.Text(string="ملاحظة")

    is_late = fields.Boolean(
        string="متأخرة", compute="_compute_is_late", search="_search_is_late",
    )
    days_late = fields.Integer(string="أيام التأخير", compute="_compute_is_late")

    _unique_occurrence = models.Constraint(
        "UNIQUE(task_id, due_date)",
        "المهمة مسجّلة مسبقاً لنفس التاريخ.",
    )

    @api.model
    def _group_expand_state(self, values, domain):
        return ["todo", "done", "skipped"]

    @api.model
    def _group_expand_frequency(self, values, domain):
        return [f[0] for f in FREQUENCIES]

    @api.depends("due_date", "state")
    def _compute_is_late(self):
        today = fields.Date.context_today(self)
        for occ in self:
            late = bool(
                occ.state == "todo" and occ.due_date and occ.due_date < today
            )
            occ.is_late = late
            occ.days_late = (today - occ.due_date).days if late else 0

    def _search_is_late(self, operator, value):
        if operator in ("in", "not in"):
            vals = list(value) if isinstance(value, (list, tuple, set)) else [value]
            truthy = any(bool(v) for v in vals)
            truthy = truthy if operator == "in" else not truthy
        elif operator in ("=", "!=", "=="):
            truthy = bool(value)
            truthy = truthy if operator in ("=", "==") else not truthy
        else:
            raise ValueError("عملية بحث غير مدعومة: %s" % operator)
        today = fields.Date.context_today(self)
        late = [("state", "=", "todo"), ("due_date", "<", today)]
        if truthy:
            return late
        return ["!", "&"] + late

    def action_done(self):
        for occ in self:
            occ.write({
                "state": "done",
                "done_by_id": self.env.user.id,
                "done_date": fields.Date.context_today(occ),
            })
        return True

    def action_skip(self):
        for occ in self:
            occ.write({
                "state": "skipped",
                "done_by_id": self.env.user.id,
                "done_date": fields.Date.context_today(occ),
            })
        return True

    def action_reset(self):
        for occ in self:
            occ.write({"state": "todo", "done_by_id": False, "done_date": False})
        return True
