# -*- coding: utf-8 -*-
"""شركات الشحن — رابط التتبع المباشر ومفاتيح مزوّد التتبع الآلي."""
from odoo import api, fields, models


class PrShippingCarrier(models.Model):
    _name = "pr.shipping.carrier"
    _description = "شركة شحن"
    _order = "sequence, name"

    name = fields.Char(string="اسم الشركة", required=True, translate=False)
    code = fields.Char(
        string="الرمز", required=True,
        help="رمز الشركة عند مزوّد التتبع (مثل: dhl, aramex, fedex, ups, smsa).",
    )
    sequence = fields.Integer(string="الترتيب", default=10)
    active = fields.Boolean(string="نشط", default=True)
    tracking_url_template = fields.Char(
        string="قالب رابط التتبع",
        help="ضع {tracking} مكان رقم التتبع. مثال:\n"
             "https://www.dhl.com/sa-en/home/tracking.html?tracking-id={tracking}",
    )
    note = fields.Char(string="ملاحظات")

    _code_uniq = models.Constraint(
        "unique(code)", "رمز شركة الشحن لازم يكون فريداً.",
    )

    def build_tracking_url(self, tracking_ref):
        """يبني رابط التتبع المباشر — بدون أي مفتاح API."""
        self.ensure_one()
        if not tracking_ref or not self.tracking_url_template:
            return False
        return self.tracking_url_template.replace("{tracking}", tracking_ref.strip())
