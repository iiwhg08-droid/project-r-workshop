# -*- coding: utf-8 -*-
from odoo import fields, models


class AccountMove(models.Model):
    _inherit = "account.move"

    pr_job_card_id = fields.Many2one(
        "pr.job.card", string="بطاقة العمل", index=True, copy=False,
        help="بطاقة الورشة التي صدرت منها هذه الفاتورة.",
    )
