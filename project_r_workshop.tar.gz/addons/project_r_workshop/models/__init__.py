# -*- coding: utf-8 -*-
from . import shipping_carrier
from . import tracking_service
from . import department
from . import job_card
from . import job_stage
from . import job_part
from . import job_photo
from . import material_issue
from . import account_move
from . import res_config_settings
