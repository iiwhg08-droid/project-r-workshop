# -*- coding: utf-8 -*-
from odoo import api, fields, models


class PrJobPhoto(models.Model):
    _name = "pr.job.photo"
    _description = "صورة على بطاقة العمل"
    _order = "job_id, phase, id"

    PHASES = [
        ("before", "قبل العمل"),
        ("during", "أثناء العمل"),
        ("after", "بعد الانتهاء"),
        ("damage", "ملاحظة أو ضرر"),
    ]

    job_id = fields.Many2one(
        "pr.job.card", string="بطاقة العمل",
        required=True, ondelete="cascade", index=True,
    )
    stage_id = fields.Many2one(
        "pr.job.stage", string="المرحلة",
        domain="[('job_id', '=', job_id)]",
    )
    phase = fields.Selection(
        PHASES, string="المرحلة الزمنية", default="before", required=True, index=True,
    )
    name = fields.Char(string="الوصف")
    image = fields.Image(string="الصورة", required=True, max_width=1920, max_height=1920)
    image_128 = fields.Image(
        string="مصغّرة", related="image", max_width=128, max_height=128, store=True,
    )
    user_id = fields.Many2one(
        "res.users", string="رفعها", default=lambda self: self.env.user, readonly=True,
    )
    date = fields.Datetime(
        string="التاريخ", default=fields.Datetime.now, readonly=True,
    )
    note = fields.Text(string="ملاحظات")

    @api.depends("job_id.name", "phase", "name")
    def _compute_display_name(self):
        labels = dict(self._fields["phase"].selection)
        for photo in self:
            photo.display_name = photo.name or "%s — %s" % (
                photo.job_id.name or "", labels.get(photo.phase, ""),
            )
