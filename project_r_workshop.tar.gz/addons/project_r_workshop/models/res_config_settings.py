# -*- coding: utf-8 -*-
from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    pr_tracking_provider = fields.Selection(
        [
            ("none", "بدون تتبع آلي"),
            ("trackingmore", "TrackingMore"),
            ("aftership", "AfterShip"),
        ],
        string="مزوّد التتبع", default="none",
        config_parameter="pr_workshop.tracking_provider",
    )
    pr_tracking_api_key = fields.Char(
        string="مفتاح الـ API",
        config_parameter="pr_workshop.tracking_api_key",
    )
    pr_tracking_interval_hours = fields.Integer(
        string="فحص كل (ساعة)", default=4,
        config_parameter="pr_workshop.tracking_interval_hours",
    )

    def set_values(self):
        res = super().set_values()
        hours = int(self.pr_tracking_interval_hours or 4)
        hours = max(1, min(hours, 24))
        cron = self.env.ref(
            "project_r_workshop.ir_cron_pr_tracking_sync", raise_if_not_found=False,
        )
        if cron:
            cron.sudo().write({
                "interval_number": hours,
                "interval_type": "hours",
                "active": (self.pr_tracking_provider or "none") != "none"
                and bool(self.pr_tracking_api_key),
            })
        return res
