# -*- coding: utf-8 -*-
"""سجل أصول الورشة — العدد والأجهزة والمعدات وتجهيزات قسم التصوير.

الغرض: تعرف وش تملك الورشة، وكم كلّفك، ووين هو، وتحت عهدة مين.
"""
from odoo import api, fields, models

CATEGORIES = [
    ("tools", "عدد وأدوات"),
    ("machines", "معدات ومكائن"),
    ("photo", "تجهيزات تصوير"),
    ("it", "أجهزة وتقنية"),
    ("furniture", "أثاث وتجهيزات"),
    ("vehicle", "مركبات"),
    ("other", "أخرى"),
]

STATES = [
    ("in_use", "قيد الاستخدام"),
    ("storage", "في المخزن"),
    ("maintenance", "تحت الصيانة"),
    ("lost", "مفقود"),
    ("disposed", "مستبعد"),
]


class PrAsset(models.Model):
    _name = "pr.asset"
    _description = "أصل من أصول الورشة"
    _inherit = ["mail.thread"]
    _order = "category, name"

    name = fields.Char(string="الأصل", required=True, tracking=True)
    code = fields.Char(
        string="رقم الأصل", copy=False, readonly=True, default="جديد", index=True,
    )
    category = fields.Selection(
        CATEGORIES, string="التصنيف", required=True, default="tools",
        tracking=True, index=True, group_expand="_group_expand_category",
    )
    state = fields.Selection(
        STATES, string="الحالة", required=True, default="in_use",
        tracking=True, index=True, group_expand="_group_expand_state",
    )
    active = fields.Boolean(string="نشط", default=True)

    department_id = fields.Many2one("pr.department", string="القسم")
    custodian_id = fields.Many2one(
        "res.users", string="العهدة على",
        help="الشخص المسؤول عن الأصل — هو اللي يُسأل عنه.",
    )
    location = fields.Char(string="الموقع", help="وين الأصل موجود فعلياً.")

    purchase_date = fields.Date(string="تاريخ الشراء", tracking=True)
    cost = fields.Monetary(
        string="التكلفة", currency_field="currency_id", tracking=True,
        help="المبلغ المدفوع فعلياً شامل الضريبة والشحن.",
    )
    company_id = fields.Many2one(
        "res.company", string="الشركة", required=True,
        default=lambda self: self.env.company,
    )
    currency_id = fields.Many2one(
        "res.currency", related="company_id.currency_id", store=True, readonly=True,
    )
    partner_id = fields.Many2one("res.partner", string="المورد")
    invoice_ref = fields.Char(
        string="مرجع الفاتورة",
        help="رقم فاتورة الشراء — يسهّل الرجوع للمستند.",
    )
    serial_no = fields.Char(string="الرقم التسلسلي")
    warranty_end = fields.Date(string="نهاية الضمان")
    image = fields.Image(string="صورة", max_width=1024, max_height=1024)
    note = fields.Text(string="ملاحظات")

    age_days = fields.Integer(string="عمر الأصل (يوم)", compute="_compute_age")
    under_warranty = fields.Boolean(
        string="تحت الضمان", compute="_compute_warranty",
        search="_search_under_warranty",
    )

    @api.model
    def _group_expand_category(self, values, domain):
        return [c[0] for c in CATEGORIES]

    @api.model
    def _group_expand_state(self, values, domain):
        return [s[0] for s in STATES if s[0] not in ("disposed", "lost")]

    @api.depends("purchase_date")
    def _compute_age(self):
        today = fields.Date.context_today(self)
        for asset in self:
            asset.age_days = (today - asset.purchase_date).days if asset.purchase_date else 0

    @api.depends("warranty_end")
    def _compute_warranty(self):
        today = fields.Date.context_today(self)
        for asset in self:
            asset.under_warranty = bool(asset.warranty_end and asset.warranty_end >= today)

    def _search_under_warranty(self, operator, value):
        if operator in ("in", "not in"):
            vals = list(value) if isinstance(value, (list, tuple, set)) else [value]
            truthy = any(bool(v) for v in vals)
            truthy = truthy if operator == "in" else not truthy
        elif operator in ("=", "!=", "=="):
            truthy = bool(value)
            truthy = truthy if operator in ("=", "==") else not truthy
        else:
            raise ValueError("عملية بحث غير مدعومة: %s" % operator)
        today = fields.Date.context_today(self)
        if truthy:
            return [("warranty_end", ">=", today)]
        return ["|", ("warranty_end", "=", False), ("warranty_end", "<", today)]

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get("code") or vals.get("code") == "جديد":
                vals["code"] = self.env["ir.sequence"].next_by_code("pr.asset") or "جديد"
        return super().create(vals_list)

    @api.depends("name", "code")
    def _compute_display_name(self):
        for asset in self:
            asset.display_name = "%s — %s" % (asset.code or "", asset.name or "")
