# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.exceptions import UserError


class PrJobStage(models.Model):
    _name = "pr.job.stage"
    _description = "مرحلة على بطاقة العمل"
    _inherit = ["mail.thread"]
    _order = "job_id, sequence, id"

    STATES = [
        ("pending", "لم تبدأ"),
        ("progress", "قيد العمل"),
        ("self_check", "فحص ذاتي"),
        ("approved", "معتمدة فنياً"),
    ]

    job_id = fields.Many2one(
        "pr.job.card", string="بطاقة العمل",
        required=True, ondelete="cascade", index=True,
    )
    sequence = fields.Integer(string="الترتيب", default=10)
    department_id = fields.Many2one(
        "pr.department", string="القسم", required=True,
    )
    technician_id = fields.Many2one("res.users", string="الفني المسؤول")
    state = fields.Selection(
        STATES, string="الحالة", default="pending", required=True, tracking=True,
    )

    date_start = fields.Datetime(string="بدأت في", readonly=True)
    date_done = fields.Datetime(string="انتهت في", readonly=True)

    # ------------------------------------------------------------------
    # إقرار التسليم بين الأقسام
    # ------------------------------------------------------------------
    handover_ok = fields.Boolean(
        string="أُقرّ انتهاء الدور", readonly=True, tracking=True, copy=False,
        help="إقرار الفني أمام المشرف بأن دور قسمه انتهى. "
             "بعد هذا الإقرار لا يُلقى اللوم على هذا القسم عن عيوب القسم التالي.",
    )
    handover_date = fields.Datetime(string="وقت الإقرار", readonly=True, copy=False)
    handover_user_id = fields.Many2one(
        "res.users", string="أقرّ بذلك", readonly=True, copy=False,
    )

    predecessor_ready = fields.Boolean(
        string="القسم السابق جاهز", compute="_compute_predecessor_ready",
    )
    blocking_message = fields.Char(
        string="سبب التوقف", compute="_compute_predecessor_ready",
    )

    # ------------------------------------------------------------------
    # الإعادة
    # ------------------------------------------------------------------
    rework = fields.Boolean(string="أُعيد العمل", tracking=True)
    rework_reason = fields.Text(
        string="السبب الفني للإعادة",
        help="يُكتب السبب الفني فقط بدون أسماء — الهدف معرفة أين تتكرر المشكلة.",
    )
    note = fields.Text(string="ملاحظات")

    # ==================================================================
    @api.depends(
        "department_id", "job_id.stage_ids.handover_ok",
        "job_id.stage_ids.department_id",
    )
    def _compute_predecessor_ready(self):
        for stage in self:
            dept = stage.department_id
            stage.blocking_message = False
            if not dept or not dept.require_predecessor_signoff or not dept.predecessor_id:
                stage.predecessor_ready = True
                continue
            prev_stages = stage.job_id.stage_ids.filtered(
                lambda s, d=dept.predecessor_id: s.department_id == d
            )
            if not prev_stages:
                stage.predecessor_ready = True
                continue
            ready = all(prev_stages.mapped("handover_ok"))
            stage.predecessor_ready = ready
            if not ready:
                stage.blocking_message = (
                    "بانتظار إقرار قسم %s بانتهاء دوره" % dept.predecessor_id.name
                )

    @api.depends("job_id.name", "department_id.name")
    def _compute_display_name(self):
        for stage in self:
            stage.display_name = "%s / %s" % (
                stage.job_id.name or "", stage.department_id.name or "",
            )

    # ==================================================================
    # الإجراءات
    # ==================================================================
    def action_start(self):
        for stage in self:
            if stage.state != "pending":
                raise UserError("هذي المرحلة بدأت من قبل.")
            dept = stage.department_id
            if dept.require_predecessor_signoff and dept.predecessor_id:
                prev_stages = stage.job_id.stage_ids.filtered(
                    lambda s, d=dept.predecessor_id: s.department_id == d
                )
                if prev_stages and not all(prev_stages.mapped("handover_ok")):
                    raise UserError(
                        "ما يمكن يبدأ قسم %(dept)s قبل ما يقرّ قسم %(prev)s "
                        "بانتهاء دوره على هالبطاقة.\n\n"
                        "هذي قاعدة ثابتة: بدون الإقرار، لو طلع عيب لاحقاً "
                        "يرجع اللوم على القسم السابق بدون وجه حق."
                        % {"dept": dept.name, "prev": dept.predecessor_id.name}
                    )
            stage.write({
                "state": "progress",
                "date_start": fields.Datetime.now(),
            })
        return True

    def action_handover(self):
        """إقرار الفني بانتهاء دوره — يُسجَّل بالتاريخ والوقت والاسم."""
        for stage in self:
            if stage.state != "progress":
                raise UserError("لا يمكن الإقرار إلا على مرحلة قيد العمل.")
            stage.write({
                "state": "self_check",
                "handover_ok": True,
                "handover_date": fields.Datetime.now(),
                "handover_user_id": self.env.user.id,
                "date_done": fields.Datetime.now(),
            })
            stage.message_post(
                body="أقرّ %s بانتهاء دور قسم %s." % (
                    self.env.user.name, stage.department_id.name,
                )
            )
        return True

    def action_supervisor_approve(self):
        """اعتماد المشرف الفني للمرحلة."""
        if not self.env.user.has_group("project_r_workshop.group_pr_supervisor"):
            raise UserError("اعتماد المراحل من صلاحية المشرف الفني فقط.")
        for stage in self:
            if stage.state != "self_check":
                raise UserError(
                    "لا يمكن الاعتماد قبل الفحص الذاتي وإقرار انتهاء الدور."
                )
            stage.state = "approved"
        return True

    def action_send_back(self):
        """إرجاع المرحلة للإعادة مع تسجيل السبب الفني."""
        for stage in self:
            if stage.state not in ("self_check", "approved"):
                raise UserError("لا يوجد ما يُعاد في هذي المرحلة.")
            stage.write({
                "state": "progress",
                "rework": True,
                "handover_ok": False,
                "handover_date": False,
                "handover_user_id": False,
                "date_done": False,
            })
            stage.message_post(body="أُعيدت المرحلة — يُرجى تسجيل السبب الفني.")
        return True
