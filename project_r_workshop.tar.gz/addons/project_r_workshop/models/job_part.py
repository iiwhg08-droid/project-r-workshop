# -*- coding: utf-8 -*-
import logging

from odoo import api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


def _bool_search_positive(operator, value):
    """يحوّل (عملية, قيمة) لبحث منطقي إلى True/False — يدعم =, !=, in, not in."""
    if operator in ("in", "not in"):
        values = list(value) if isinstance(value, (list, tuple, set)) else [value]
        truthy = any(bool(v) for v in values)
        return truthy if operator == "in" else not truthy
    if operator in ("=", "!=", "=="):
        truthy = bool(value)
        return truthy if operator in ("=", "==") else not truthy
    raise ValueError("عملية بحث غير مدعومة على حقل منطقي: %s" % operator)


class PrJobPart(models.Model):
    _name = "pr.job.part"
    _description = "قطعة مطلوبة على بطاقة عمل"
    _inherit = ["mail.thread"]
    _order = "sequence, id desc"

    STATES = [
        ("sourcing", "جاري البحث والتسعير"),
        ("draft", "بانتظار الموافقة"),
        ("mgr_approved", "اعتماد أول"),
        ("dir_approved", "اعتماد ثانٍ"),
        ("ordered", "تم الطلب"),
        ("transit", "في الطريق"),
        ("received", "وصلت الورشة"),
        ("rejected", "مرفوضة"),
    ]
    # المراحل التي لا تُحتسب تكلفتها على البطاقة بعد
    UNCOSTED = ("sourcing", "draft", "rejected")
    SHIPMENT = [
        ("none", "لا يوجد شحن"),
        ("pending", "بانتظار الشحن"),
        ("transit", "في الطريق"),
        ("arrived", "وصلت"),
    ]

    sequence = fields.Integer(string="الترتيب", default=10)
    job_id = fields.Many2one(
        "pr.job.card", string="بطاقة العمل",
        required=True, ondelete="cascade", index=True,
    )
    job_ref = fields.Char(
        string="رقم البطاقة", related="job_id.name", store=True, index=True,
    )
    partner_id = fields.Many2one(
        "res.partner", string="العميل", related="job_id.partner_id", store=True,
    )
    vehicle_label = fields.Char(
        string="السيارة", compute="_compute_vehicle_label", store=True,
    )
    department_id = fields.Many2one("pr.department", string="القسم الطالب")
    product_id = fields.Many2one("product.product", string="الصنف")
    name = fields.Char(string="وصف القطعة", required=True)
    qty = fields.Float(string="الكمية", default=1.0, required=True)
    reason = fields.Text(
        string="سبب الطلب", required=True,
        help="لماذا تُغيَّر هذي القطعة — يُكتب على البطاقة.",
    )
    alternative = fields.Char(string="البديل المتاح")

    currency_id = fields.Many2one(
        "res.currency", related="job_id.currency_id", store=True, readonly=True,
    )
    unit_cost = fields.Monetary(string="التكلفة", currency_field="currency_id")
    subtotal = fields.Monetary(
        string="إجمالي التكلفة", compute="_compute_subtotal", store=True,
        currency_field="currency_id",
    )
    sale_price = fields.Monetary(
        string="سعر البيع", currency_field="currency_id",
        help="السعر المحتسب على العميل — يُستخدم في الفاتورة. اتركه فارغاً لو القطعة غير مفوترة.",
    )
    sale_subtotal = fields.Monetary(
        string="إجمالي البيع", compute="_compute_subtotal", store=True,
        currency_field="currency_id",
    )
    is_extra = fields.Boolean(
        string="خارج الاتفاق", default=False, index=True,
        help="قطعة ما كانت ضمن السعر المتفق عليه مع العميل — طلعت أثناء العمل "
             "(كفرات، قطعة مفاجئة). تُحتسب ضمن «التكاليف الإضافية» في المؤشرات.",
    )

    # ------------------------------------------------------------------
    # من يحدد؟ المشرف الفني مع فني القسم — الاثنين معاً
    # ------------------------------------------------------------------
    determined_by_id = fields.Many2one(
        "res.users", string="حدّدها المشرف", required=True,
        default=lambda self: self.env.user,
    )
    technician_id = fields.Many2one(
        "res.users", string="فني القسم", required=True,
        help="فني القسم المعني الذي حدّد القطعة مع المشرف الفني.",
    )

    # ------------------------------------------------------------------
    # الاعتماد على مرحلتين
    # ------------------------------------------------------------------
    state = fields.Selection(
        STATES, string="المرحلة", default="draft", required=True, tracking=True,
        group_expand="_group_expand_state",
    )
    needs_director = fields.Boolean(
        string="يحتاج اعتماداً ثانياً", default=False, tracking=True,
        help="للقطع الكبيرة أو غير الاعتيادية — تحتاج اعتماد الإدارة العليا بعد الأول.",
    )
    manager_id = fields.Many2one(
        "res.users", string="الاعتماد الأول", readonly=True, copy=False, tracking=True,
    )
    manager_date = fields.Datetime(string="تاريخ الاعتماد الأول", readonly=True, copy=False)
    director_id = fields.Many2one(
        "res.users", string="الاعتماد الثاني", readonly=True, copy=False, tracking=True,
    )
    director_date = fields.Datetime(string="تاريخ الاعتماد الثاني", readonly=True, copy=False)
    reject_reason = fields.Char(string="سبب الرفض", copy=False)

    # ------------------------------------------------------------------
    # الشحن
    # ------------------------------------------------------------------
    supplier_id = fields.Many2one("res.partner", string="المورّد")
    shipment_state = fields.Selection(
        SHIPMENT, string="حالة الشحنة", default="none", tracking=True,
    )
    tracking_ref = fields.Char(string="رقم التتبع", index=True, tracking=True)
    carrier_id = fields.Many2one(
        "pr.shipping.carrier", string="شركة الشحن", tracking=True,
    )
    tracking_url = fields.Char(
        string="رابط التتبع", compute="_compute_tracking_url",
        help="يُبنى تلقائياً من رقم التتبع وشركة الشحن — يفتح صفحة الشركة مباشرة.",
    )
    product_url = fields.Char(
        string="رابط القطعة", help="رابط صفحة القطعة عند المورّد أو المتجر.",
    )
    order_date = fields.Date(string="تاريخ الطلب", readonly=True, copy=False)
    eta_date = fields.Date(string="الوصول المتوقع")
    auto_track = fields.Boolean(
        string="تتبع آلي", default=True,
        help="يسحب النظام حالة الشحنة من شركة الشحن دورياً ويحرّك البطاقة تلقائياً.",
    )
    tracking_sync_date = fields.Datetime(
        string="آخر تحديث آلي", readonly=True, copy=False,
    )
    tracking_status_raw = fields.Char(
        string="حالة المزوّد", readonly=True, copy=False,
        help="آخر حالة وردت من شركة الشحن كما هي.",
    )
    days_open = fields.Integer(
        string="أيام منذ الطلب", compute="_compute_days_open",
    )
    is_overdue = fields.Boolean(
        string="تجاوزت الموعد", compute="_compute_days_open",
        search="_search_is_overdue",
    )

    # ==================================================================
    @api.model
    def _group_expand_state(self, states, domain):
        """تعرض اللوحة كل المراحل حتى الفارغة — عدا المرفوضة."""
        return [s[0] for s in self.STATES if s[0] != "rejected"]

    @api.depends("qty", "unit_cost", "sale_price")
    def _compute_subtotal(self):
        for part in self:
            qty = part.qty or 0.0
            part.subtotal = qty * (part.unit_cost or 0.0)
            part.sale_subtotal = qty * (part.sale_price or 0.0)

    @api.depends("job_id.vehicle_make", "job_id.vehicle_model", "job_id.plate_no")
    def _compute_vehicle_label(self):
        for part in self:
            job = part.job_id
            bits = [b for b in (job.vehicle_make, job.vehicle_model) if b]
            label = " ".join(bits)
            if job.plate_no:
                label = "%s [%s]" % (label, job.plate_no) if label else job.plate_no
            part.vehicle_label = label or False

    @api.depends("tracking_ref", "carrier_id")
    def _compute_tracking_url(self):
        for part in self:
            part.tracking_url = (
                part.carrier_id.build_tracking_url(part.tracking_ref)
                if part.carrier_id and part.tracking_ref else False
            )

    def _search_is_overdue(self, operator, value):
        today = fields.Date.context_today(self)
        overdue = [
            "&", "&",
            ("eta_date", "!=", False),
            ("eta_date", "<", today),
            ("state", "not in", ("received", "rejected")),
        ]
        return overdue if _bool_search_positive(operator, value) else ["!"] + overdue

    @api.depends("order_date", "eta_date", "state")
    def _compute_days_open(self):
        today = fields.Date.context_today(self)
        for part in self:
            part.days_open = (today - part.order_date).days if part.order_date else 0
            part.is_overdue = bool(
                part.eta_date and part.state not in ("received", "rejected")
                and part.eta_date < today
            )

    @api.onchange("product_id")
    def _onchange_product_id(self):
        if self.product_id:
            if not self.name:
                self.name = self.product_id.display_name
            if not self.unit_cost:
                self.unit_cost = self.product_id.standard_price
            if not self.sale_price:
                self.sale_price = self.product_id.list_price

    @api.onchange("unit_cost")
    def _onchange_unit_cost(self):
        """اقتراح سعر بيع مبدئي = التكلفة، يعدّله المستخدم."""
        if self.unit_cost and not self.sale_price:
            self.sale_price = self.unit_cost

    # ==================================================================
    # الاعتمادات
    # ==================================================================
    def action_approve_manager(self):
        """الاعتماد الأول — الإدارة التنفيذية."""
        if not self.env.user.has_group("project_r_workshop.group_pr_manager"):
            raise UserError("الاعتماد الأول من صلاحية الإدارة التنفيذية.")
        for part in self:
            if part.state != "draft":
                raise UserError("هذي القطعة تجاوزت مرحلة الاعتماد الأول.")
            if not part.technician_id:
                raise UserError(
                    "لازم يكون فني القسم محدّداً — القطع تُحدَّد بالمشرف مع الفني، "
                    "مو بواحد لوحده."
                )
            part.write({
                "state": "mgr_approved",
                "manager_id": self.env.user.id,
                "manager_date": fields.Datetime.now(),
            })
        return True

    def action_approve_director(self):
        """الاعتماد الثاني — الإدارة العليا."""
        if not self.env.user.has_group("project_r_workshop.group_pr_director"):
            raise UserError("الاعتماد الثاني من صلاحية الإدارة العليا.")
        for part in self:
            if part.state != "mgr_approved":
                raise UserError("لا يصدر الاعتماد الثاني قبل الأول.")
            part.write({
                "state": "dir_approved",
                "director_id": self.env.user.id,
                "director_date": fields.Datetime.now(),
            })
        return True

    def action_request_approval(self):
        """من البحث والتسعير إلى بانتظار الموافقة."""
        for part in self:
            if part.state != "sourcing":
                raise UserError("هذي القطعة تجاوزت مرحلة البحث والتسعير.")
            if not part.unit_cost:
                raise UserError(
                    "أدخل التكلفة قبل رفعها للموافقة — "
                    "ما يُعتمد طلب بدون سعر."
                )
            part.state = "draft"
        return True

    def action_order(self):
        for part in self:
            if part.state not in ("mgr_approved", "dir_approved"):
                raise UserError("لا تُشترى قطعة بدون اعتماد مسجّل.")
            if part.needs_director and part.state != "dir_approved":
                raise UserError(
                    "هذي القطعة معلّمة بأنها تحتاج اعتماداً ثانياً — "
                    "ما تُشترى قبل اعتماد الإدارة العليا."
                )
            part.write({
                "state": "ordered",
                "order_date": fields.Date.context_today(part),
                "shipment_state": "pending" if part.shipment_state == "none"
                else part.shipment_state,
            })
            part._register_tracking()
        return True

    def action_mark_transit(self):
        for part in self:
            if part.state not in ("ordered", "transit"):
                raise UserError("لا تُشحن قطعة قبل طلبها.")
            part.write({"state": "transit", "shipment_state": "transit"})
        return True

    def action_receive(self):
        for part in self:
            if part.state not in ("ordered", "transit"):
                raise UserError("لا يمكن الاستلام قبل الطلب.")
            part.write({"state": "received", "shipment_state": "arrived"})
        return True

    def action_open_tracking(self):
        self.ensure_one()
        if not self.tracking_url:
            raise UserError(
                "ما فيه رابط تتبع — أدخل رقم التتبع واختر شركة الشحن."
            )
        return {"type": "ir.actions.act_url", "url": self.tracking_url, "target": "new"}

    def action_reject(self):
        for part in self:
            part.state = "rejected"
        return True

    def action_reset(self):
        self.write({
            "state": "draft",
            "manager_id": False, "manager_date": False,
            "director_id": False, "director_date": False,
        })
        return True

    # ==================================================================
    # التتبع الآلي
    # ==================================================================
    def _register_tracking(self):
        """يسجّل الشحنة عند مزوّد التتبع — بهدوء لو ما فيه مفتاح."""
        service = self.env["pr.tracking.service"]
        if not service.is_enabled():
            return
        for part in self:
            if part.auto_track and part.tracking_ref and part.carrier_id.code:
                service.register(part.tracking_ref, part.carrier_id.code)

    def action_sync_tracking(self):
        """سحب حالة الشحنة الآن — يدوياً من زر على البطاقة."""
        service = self.env["pr.tracking.service"]
        if not service.is_enabled():
            raise UserError(
                "التتبع الآلي غير مُفعّل.\n\n"
                "من الإعدادات ← إعدادات التتبع، اختر المزوّد وضع مفتاح الـ API."
            )
        self._sync_tracking()
        return True

    def _sync_tracking(self):
        service = self.env["pr.tracking.service"]
        if not service.is_enabled():
            return 0
        moved = 0
        for part in self:
            if not (part.auto_track and part.tracking_ref and part.carrier_id.code):
                continue
            res = service.fetch_status(part.tracking_ref, part.carrier_id.code)
            vals = {"tracking_sync_date": fields.Datetime.now()}
            if res:
                vals["tracking_status_raw"] = res.get("status") or False
                new_state = res.get("mapped_state")
                # لا نرجع البطاقة للخلف، ولا نلمس المرفوضة
                order = ["ordered", "transit", "received"]
                if (
                    new_state in order
                    and part.state in order
                    and order.index(new_state) > order.index(part.state)
                ):
                    vals["state"] = new_state
                    vals["shipment_state"] = (
                        "arrived" if new_state == "received" else "transit"
                    )
                    moved += 1
                    part.message_post(
                        body="تحديث آلي من %s: %s" % (
                            part.carrier_id.name, res.get("status") or "-",
                        )
                    )
            part.write(vals)
        return moved

    @api.model
    def _cron_sync_tracking(self):
        """المهمة المجدولة — تسحب حالات الشحنات المفتوحة."""
        service = self.env["pr.tracking.service"]
        if not service.is_enabled():
            return True
        parts = self.search([
            ("state", "in", ("ordered", "transit")),
            ("auto_track", "=", True),
            ("tracking_ref", "!=", False),
            ("carrier_id", "!=", False),
        ], limit=200)
        if parts:
            moved = parts._sync_tracking()
            _logger.info(
                "تتبع الشحنات: فُحصت %s شحنة، تحرّكت %s.", len(parts), moved,
            )
        return True
