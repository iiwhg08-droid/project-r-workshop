# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.exceptions import UserError


class PrJobPart(models.Model):
    _name = "pr.job.part"
    _description = "قطعة مطلوبة على بطاقة عمل"
    _inherit = ["mail.thread"]
    _order = "job_id, id"

    STATES = [
        ("draft", "مطلوبة"),
        ("mgr_approved", "اعتماد أول"),
        ("dir_approved", "اعتماد ثانٍ"),
        ("ordered", "تم الشراء"),
        ("received", "مُستلمة"),
        ("rejected", "مرفوضة"),
    ]
    SHIPMENT = [
        ("none", "لا يوجد شحن"),
        ("pending", "بانتظار الشحن"),
        ("transit", "في الطريق"),
        ("arrived", "وصلت"),
    ]

    job_id = fields.Many2one(
        "pr.job.card", string="بطاقة العمل",
        required=True, ondelete="cascade", index=True,
    )
    department_id = fields.Many2one("pr.department", string="القسم الطالب")
    product_id = fields.Many2one("product.product", string="الصنف")
    name = fields.Char(string="وصف القطعة", required=True)
    qty = fields.Float(string="الكمية", default=1.0, required=True)
    reason = fields.Text(
        string="سبب الطلب", required=True,
        help="لماذا تُغيَّر هذي القطعة — يُكتب على البطاقة.",
    )
    alternative = fields.Char(string="البديل المتاح")

    currency_id = fields.Many2one(
        "res.currency", related="job_id.currency_id", store=True, readonly=True,
    )
    unit_cost = fields.Monetary(string="التكلفة", currency_field="currency_id")
    subtotal = fields.Monetary(
        string="إجمالي التكلفة", compute="_compute_subtotal", store=True,
        currency_field="currency_id",
    )
    sale_price = fields.Monetary(
        string="سعر البيع", currency_field="currency_id",
        help="السعر المحتسب على العميل — يُستخدم في الفاتورة. اتركه فارغاً لو القطعة غير مفوترة.",
    )
    sale_subtotal = fields.Monetary(
        string="إجمالي البيع", compute="_compute_subtotal", store=True,
        currency_field="currency_id",
    )

    # ------------------------------------------------------------------
    # من يحدد؟ المشرف الفني مع فني القسم — الاثنين معاً
    # ------------------------------------------------------------------
    determined_by_id = fields.Many2one(
        "res.users", string="حدّدها المشرف", required=True,
        default=lambda self: self.env.user,
    )
    technician_id = fields.Many2one(
        "res.users", string="فني القسم", required=True,
        help="فني القسم المعني الذي حدّد القطعة مع المشرف الفني.",
    )

    # ------------------------------------------------------------------
    # الاعتماد على مرحلتين
    # ------------------------------------------------------------------
    state = fields.Selection(
        STATES, string="الحالة", default="draft", required=True, tracking=True,
    )
    needs_director = fields.Boolean(
        string="يحتاج اعتماداً ثانياً", default=False, tracking=True,
        help="للقطع الكبيرة أو غير الاعتيادية — تحتاج اعتماد الإدارة العليا بعد الأول.",
    )
    manager_id = fields.Many2one(
        "res.users", string="الاعتماد الأول", readonly=True, copy=False, tracking=True,
    )
    manager_date = fields.Datetime(string="تاريخ الاعتماد الأول", readonly=True, copy=False)
    director_id = fields.Many2one(
        "res.users", string="الاعتماد الثاني", readonly=True, copy=False, tracking=True,
    )
    director_date = fields.Datetime(string="تاريخ الاعتماد الثاني", readonly=True, copy=False)
    reject_reason = fields.Char(string="سبب الرفض", copy=False)

    # ------------------------------------------------------------------
    # الشحن
    # ------------------------------------------------------------------
    supplier_id = fields.Many2one("res.partner", string="المورّد")
    shipment_state = fields.Selection(
        SHIPMENT, string="حالة الشحنة", default="none", tracking=True,
    )
    tracking_ref = fields.Char(string="رقم التتبع")
    eta_date = fields.Date(string="الوصول المتوقع")

    # ==================================================================
    @api.depends("qty", "unit_cost", "sale_price")
    def _compute_subtotal(self):
        for part in self:
            qty = part.qty or 0.0
            part.subtotal = qty * (part.unit_cost or 0.0)
            part.sale_subtotal = qty * (part.sale_price or 0.0)

    @api.onchange("product_id")
    def _onchange_product_id(self):
        if self.product_id:
            if not self.name:
                self.name = self.product_id.display_name
            if not self.unit_cost:
                self.unit_cost = self.product_id.standard_price
            if not self.sale_price:
                self.sale_price = self.product_id.list_price

    @api.onchange("unit_cost")
    def _onchange_unit_cost(self):
        """اقتراح سعر بيع مبدئي = التكلفة، يعدّله المستخدم."""
        if self.unit_cost and not self.sale_price:
            self.sale_price = self.unit_cost

    # ==================================================================
    # الاعتمادات
    # ==================================================================
    def action_approve_manager(self):
        """الاعتماد الأول — الإدارة التنفيذية."""
        if not self.env.user.has_group("project_r_workshop.group_pr_manager"):
            raise UserError("الاعتماد الأول من صلاحية الإدارة التنفيذية.")
        for part in self:
            if part.state != "draft":
                raise UserError("هذي القطعة تجاوزت مرحلة الاعتماد الأول.")
            if not part.technician_id:
                raise UserError(
                    "لازم يكون فني القسم محدّداً — القطع تُحدَّد بالمشرف مع الفني، "
                    "مو بواحد لوحده."
                )
            part.write({
                "state": "mgr_approved",
                "manager_id": self.env.user.id,
                "manager_date": fields.Datetime.now(),
            })
        return True

    def action_approve_director(self):
        """الاعتماد الثاني — الإدارة العليا."""
        if not self.env.user.has_group("project_r_workshop.group_pr_director"):
            raise UserError("الاعتماد الثاني من صلاحية الإدارة العليا.")
        for part in self:
            if part.state != "mgr_approved":
                raise UserError("لا يصدر الاعتماد الثاني قبل الأول.")
            part.write({
                "state": "dir_approved",
                "director_id": self.env.user.id,
                "director_date": fields.Datetime.now(),
            })
        return True

    def action_order(self):
        for part in self:
            required = "dir_approved" if part.needs_director else "mgr_approved"
            if part.state not in ("mgr_approved", "dir_approved"):
                raise UserError("لا تُشترى قطعة بدون اعتماد مسجّل.")
            if part.needs_director and part.state != "dir_approved":
                raise UserError(
                    "هذي القطعة معلّمة بأنها تحتاج اعتماداً ثانياً — "
                    "ما تُشترى قبل اعتماد الإدارة العليا."
                )
            del required
            part.write({
                "state": "ordered",
                "shipment_state": "pending" if part.shipment_state == "none"
                else part.shipment_state,
            })
        return True

    def action_receive(self):
        for part in self:
            if part.state != "ordered":
                raise UserError("لا يمكن الاستلام قبل الشراء.")
            part.write({"state": "received", "shipment_state": "arrived"})
        return True

    def action_reject(self):
        for part in self:
            part.state = "rejected"
        return True

    def action_reset(self):
        self.write({
            "state": "draft",
            "manager_id": False, "manager_date": False,
            "director_id": False, "director_date": False,
        })
        return True
