# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.exceptions import UserError


class PrMaterialIssue(models.Model):
    _name = "pr.material.issue"
    _description = "صرف مواد من عهدة المشرف الفني"
    _inherit = ["mail.thread"]
    _order = "date desc, id desc"

    job_id = fields.Many2one(
        "pr.job.card", string="بطاقة العمل",
        required=True, ondelete="cascade", index=True,
        help="كل صرف يُسجَّل على سيارة — عشان التكلفة تطلع صحيحة.",
    )
    department_id = fields.Many2one("pr.department", string="القسم المستفيد")
    product_id = fields.Many2one("product.product", string="الصنف")
    name = fields.Char(string="وصف المادة", required=True)
    qty = fields.Float(string="الكمية", default=1.0, required=True)

    currency_id = fields.Many2one(
        "res.currency", related="job_id.currency_id", store=True, readonly=True,
    )
    unit_cost = fields.Monetary(string="سعر الوحدة", currency_field="currency_id")
    subtotal = fields.Monetary(
        string="الإجمالي", compute="_compute_subtotal", store=True,
        currency_field="currency_id",
    )
    is_extra = fields.Boolean(
        string="خارج الاتفاق", default=False, index=True,
        help="مواد ما كانت ضمن السعر المتفق عليه مع العميل — تُحتسب ضمن «التكاليف الإضافية».",
    )

    issued_by_id = fields.Many2one(
        "res.users", string="صرفها", required=True,
        default=lambda self: self.env.user, readonly=True,
        help="المخزون تحت عهدة المشرف الفني ومقفل عليه — هو من يصرف.",
    )
    received_by_id = fields.Many2one("res.users", string="استلمها الفني")
    date = fields.Datetime(
        string="تاريخ الصرف", default=fields.Datetime.now, required=True,
    )
    note = fields.Text(string="ملاحظات")

    @api.depends("qty", "unit_cost")
    def _compute_subtotal(self):
        for line in self:
            line.subtotal = (line.qty or 0.0) * (line.unit_cost or 0.0)

    @api.onchange("product_id")
    def _onchange_product_id(self):
        if self.product_id:
            if not self.name:
                self.name = self.product_id.display_name
            if not self.unit_cost:
                self.unit_cost = self.product_id.standard_price

    @api.model_create_multi
    def create(self, vals_list):
        if not self.env.user.has_group("project_r_workshop.group_pr_supervisor"):
            raise UserError(
                "صرف المواد من عهدة المشرف الفني — التسجيل من صلاحيته وحده.\n"
                "أي مادة تحتاجها اطلبها منه وتُسجَّل على بطاقة السيارة."
            )
        return super().create(vals_list)

    @api.depends("job_id.name", "name")
    def _compute_display_name(self):
        for line in self:
            line.display_name = "%s — %s" % (line.job_id.name or "", line.name or "")
