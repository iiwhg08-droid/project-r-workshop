# -*- coding: utf-8 -*-
from odoo import api, fields, models
from odoo.exceptions import ValidationError


class PrDepartment(models.Model):
    _name = "pr.department"
    _description = "قسم الورشة"
    _order = "sequence, id"

    name = fields.Char(string="اسم القسم", required=True, translate=True)
    code = fields.Char(string="الرمز", required=True)
    sequence = fields.Integer(string="الترتيب", default=10)
    active = fields.Boolean(string="نشط", default=True)

    supervisor_id = fields.Many2one(
        "res.users",
        string="المشرف",
        help="المسؤول الفني عن هذا القسم.",
    )
    member_ids = fields.Many2many(
        "res.users",
        "pr_department_users_rel",
        "department_id",
        "user_id",
        string="فنيو القسم",
    )

    predecessor_id = fields.Many2one(
        "pr.department",
        string="القسم السابق",
        help="القسم الذي يجب أن ينتهي عمله قبل أن يبدأ هذا القسم.",
    )
    require_predecessor_signoff = fields.Boolean(
        string="يشترط إقرار القسم السابق",
        default=False,
        help="عند تفعيله لا يمكن بدء مرحلة هذا القسم قبل أن يقرّ القسم السابق "
             "انتهاء دوره على البطاقة. هذا ما يمنع رجوع اللوم على القسم السابق لاحقاً.",
    )

    note = fields.Text(string="ملاحظات")

    _code_uniq = models.Constraint(
        "UNIQUE(code)", "رمز القسم يجب أن يكون فريداً.",
    )

    @api.constrains("predecessor_id")
    def _check_predecessor_recursion(self):
        for dept in self:
            visited = set()
            node = dept.predecessor_id
            while node:
                if node.id == dept.id or node.id in visited:
                    raise ValidationError(
                        "لا يمكن أن يسبق القسم نفسه — راجع سلسلة الأقسام السابقة."
                    )
                visited.add(node.id)
                node = node.predecessor_id
