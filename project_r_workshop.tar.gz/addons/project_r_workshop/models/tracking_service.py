# -*- coding: utf-8 -*-
"""التتبع الآلي للشحنات — طبقة اتصال بمزوّد خارجي (TrackingMore / AfterShip).

التصميم:
  * المفتاح والمزوّد يُحفظان في إعدادات النظام (ir.config_parameter).
  * بدون مفتاح: كل شيء يشتغل عادي، والتتبع الآلي يسكت بهدوء.
  * لا يرمي استثناءات توقف عمل الورشة — أي خطأ يُسجَّل ويُكمَل.
"""
import json
import logging
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from odoo import api, models

_logger = logging.getLogger(__name__)

TIMEOUT = 20

# حالات المزوّدين -> مرحلة الطلب عندنا
STATUS_MAP = {
    "pending": "ordered",
    "notfound": "ordered",
    "inforeceived": "ordered",
    "info_received": "ordered",
    "transit": "transit",
    "intransit": "transit",
    "in_transit": "transit",
    "outfordelivery": "transit",
    "out_for_delivery": "transit",
    "availableforpickup": "transit",
    "available_for_pickup": "transit",
    "delivered": "received",
    "exception": "transit",
    "expired": "transit",
    "undelivered": "transit",
    "attemptfail": "transit",
    "failedattempt": "transit",
}


class PrTrackingService(models.AbstractModel):
    _name = "pr.tracking.service"
    _description = "خدمة التتبع الآلي للشحنات"

    # ------------------------------------------------------------------
    # الإعدادات
    # ------------------------------------------------------------------
    @api.model
    def _get_config(self):
        icp = self.env["ir.config_parameter"].sudo()
        return {
            "provider": (icp.get_param("pr_workshop.tracking_provider") or "none").strip(),
            "api_key": (icp.get_param("pr_workshop.tracking_api_key") or "").strip(),
        }

    @api.model
    def is_enabled(self):
        cfg = self._get_config()
        return bool(cfg["api_key"]) and cfg["provider"] in ("trackingmore", "aftership")

    # ------------------------------------------------------------------
    # HTTP
    # ------------------------------------------------------------------
    @api.model
    def _http_json(self, url, headers, payload=None, method="GET"):
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = Request(url, data=data, headers=headers, method=method)
        try:
            with urlopen(req, timeout=TIMEOUT) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except HTTPError as err:
            body = ""
            try:
                body = err.read().decode("utf-8")[:500]
            except Exception:  # noqa: BLE001
                pass
            _logger.warning("تتبع الشحنات: رد %s من المزوّد — %s", err.code, body)
        except (URLError, TimeoutError) as err:
            _logger.warning("تتبع الشحنات: تعذّر الاتصال بالمزوّد — %s", err)
        except (ValueError, json.JSONDecodeError) as err:
            _logger.warning("تتبع الشحنات: رد غير مفهوم من المزوّد — %s", err)
        return None

    # ------------------------------------------------------------------
    # TrackingMore
    # ------------------------------------------------------------------
    @api.model
    def _tm_headers(self, api_key):
        return {
            "Tracking-Api-Key": api_key,
            "Content-Type": "application/json",
        }

    @api.model
    def _tm_register(self, api_key, tracking_ref, carrier_code):
        """تسجيل الشحنة عند المزوّد — يتجاهل خطأ 'مسجّلة مسبقاً'."""
        self._http_json(
            "https://api.trackingmore.com/v4/trackings/create",
            self._tm_headers(api_key),
            payload={"tracking_number": tracking_ref, "courier_code": carrier_code},
            method="POST",
        )

    @api.model
    def _tm_fetch(self, api_key, tracking_ref, carrier_code):
        url = (
            "https://api.trackingmore.com/v4/trackings/get"
            "?tracking_numbers=%s&courier_code=%s" % (tracking_ref, carrier_code)
        )
        res = self._http_json(url, self._tm_headers(api_key))
        if not res or not isinstance(res.get("data"), list) or not res["data"]:
            return None
        item = res["data"][0]
        return {
            "status": (item.get("delivery_status") or "").lower().replace(" ", ""),
            "raw": item,
        }

    # ------------------------------------------------------------------
    # AfterShip
    # ------------------------------------------------------------------
    @api.model
    def _as_headers(self, api_key):
        return {
            "as-api-key": api_key,
            "Content-Type": "application/json",
        }

    @api.model
    def _as_register(self, api_key, tracking_ref, carrier_code):
        self._http_json(
            "https://api.aftership.com/tracking/2024-04/trackings",
            self._as_headers(api_key),
            payload={"tracking_number": tracking_ref, "slug": carrier_code},
            method="POST",
        )

    @api.model
    def _as_fetch(self, api_key, tracking_ref, carrier_code):
        url = (
            "https://api.aftership.com/tracking/2024-04/trackings"
            "?tracking_numbers=%s" % tracking_ref
        )
        res = self._http_json(url, self._as_headers(api_key))
        data = (res or {}).get("data") or {}
        items = data.get("trackings") or []
        if not items:
            return None
        item = items[0]
        return {
            "status": (item.get("tag") or "").lower().replace(" ", ""),
            "raw": item,
        }

    # ------------------------------------------------------------------
    # الواجهة الموحّدة
    # ------------------------------------------------------------------
    @api.model
    def register(self, tracking_ref, carrier_code):
        cfg = self._get_config()
        if not self.is_enabled() or not tracking_ref or not carrier_code:
            return False
        if cfg["provider"] == "trackingmore":
            self._tm_register(cfg["api_key"], tracking_ref, carrier_code)
        else:
            self._as_register(cfg["api_key"], tracking_ref, carrier_code)
        return True

    @api.model
    def fetch_status(self, tracking_ref, carrier_code):
        """يرجّع dict فيه status الخام و state المقابل عندنا، أو None."""
        cfg = self._get_config()
        if not self.is_enabled() or not tracking_ref or not carrier_code:
            return None
        if cfg["provider"] == "trackingmore":
            res = self._tm_fetch(cfg["api_key"], tracking_ref, carrier_code)
        else:
            res = self._as_fetch(cfg["api_key"], tracking_ref, carrier_code)
        if not res:
            return None
        res["mapped_state"] = STATUS_MAP.get(res["status"])
        return res
