# -*- coding: utf-8 -*-
from odoo import Command, api, fields, models
from odoo.exceptions import UserError


def _bool_search_positive(operator, value):
    """يحوّل (عملية, قيمة) لبحث منطقي إلى True/False — يدعم =, !=, in, not in."""
    if operator in ("in", "not in"):
        values = list(value) if isinstance(value, (list, tuple, set)) else [value]
        truthy = any(bool(v) for v in values)
        return truthy if operator == "in" else not truthy
    if operator in ("=", "!=", "=="):
        truthy = bool(value)
        return truthy if operator in ("=", "==") else not truthy
    raise ValueError("عملية بحث غير مدعومة على حقل منطقي: %s" % operator)


class PrJobCard(models.Model):
    _name = "pr.job.card"
    _description = "بطاقة عمل"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "priority desc, id desc"

    STATES = [
        ("draft", "مسودة"),
        ("intake", "مستلمة"),
        ("progress", "قيد العمل"),
        ("quality", "تحت الفحص"),
        ("ready", "جاهزة للتسليم"),
        ("delivered", "مُسلّمة"),
        ("cancel", "ملغاة"),
    ]

    name = fields.Char(
        string="رقم البطاقة", required=True, copy=False,
        readonly=True, default="جديد", index=True,
    )
    state = fields.Selection(
        STATES, string="الحالة", default="draft",
        tracking=True, required=True, index=True,
        group_expand="_group_expand_state",
    )
    priority = fields.Selection(
        [("0", "عادي"), ("1", "مستعجل")], string="الأولوية", default="0",
    )
    active = fields.Boolean(string="نشط", default=True)
    company_id = fields.Many2one(
        "res.company", string="الشركة", required=True,
        default=lambda self: self.env.company,
    )
    currency_id = fields.Many2one(
        "res.currency", string="العملة",
        related="company_id.currency_id", store=True, readonly=True,
    )

    # ------------------------------------------------------------------
    # العميل والسيارة
    # ------------------------------------------------------------------
    partner_id = fields.Many2one(
        "res.partner", string="العميل", required=True, tracking=True,
    )
    partner_phone = fields.Char(
        string="الجوال", related="partner_id.phone", readonly=False,
    )
    vehicle_make = fields.Char(string="الماركة", tracking=True)
    vehicle_model = fields.Char(string="الموديل", tracking=True)
    vehicle_year = fields.Char(string="سنة الصنع")
    plate_no = fields.Char(string="رقم اللوحة", index=True)
    vin = fields.Char(string="رقم الهيكل (VIN)")
    color = fields.Char(string="اللون")

    # ------------------------------------------------------------------
    # الاستلام — لا سيارة تدخل بدون المشرف الفني
    # ------------------------------------------------------------------
    intake_user_id = fields.Many2one(
        "res.users", string="استلمها", readonly=True, tracking=True,
        help="المشرف الفني الذي عاين السيارة لحظة دخولها.",
    )
    intake_date = fields.Datetime(string="وقت الاستلام", readonly=True, tracking=True)
    work_requested = fields.Text(
        string="العمل المطلوب",
        help="تفاصيل ما اتُّفق عليه مع العميل، تُكتب لحظة دخول السيارة.",
    )
    expected_date = fields.Date(string="التسليم المتوقع", tracking=True)

    # ------------------------------------------------------------------
    # الأسطر
    # ------------------------------------------------------------------
    stage_ids = fields.One2many("pr.job.stage", "job_id", string="المراحل")
    part_ids = fields.One2many("pr.job.part", "job_id", string="القطع")
    photo_ids = fields.One2many("pr.job.photo", "job_id", string="الصور")
    issue_ids = fields.One2many("pr.material.issue", "job_id", string="صرف المواد")

    stage_count = fields.Integer(string="عدد المراحل", compute="_compute_counts")
    photo_count = fields.Integer(string="عدد الصور", compute="_compute_counts")
    part_count = fields.Integer(string="عدد القطع", compute="_compute_counts")
    rework_count = fields.Integer(
        string="الأعمال المعادة", compute="_compute_rework_count", store=True,
        help="عدد المراحل التي أُعيدت — مؤشر جودة، بدون أسماء.",
    )

    # ------------------------------------------------------------------
    # التكاليف
    # ------------------------------------------------------------------
    parts_cost = fields.Monetary(
        string="تكلفة القطع", compute="_compute_costs", store=True, currency_field="currency_id",
    )
    material_cost = fields.Monetary(
        string="تكلفة المواد", compute="_compute_costs", store=True, currency_field="currency_id",
    )
    total_cost = fields.Monetary(
        string="إجمالي التكلفة", compute="_compute_costs", store=True, currency_field="currency_id",
    )

    # ------------------------------------------------------------------
    # التسعير والفوترة
    # ------------------------------------------------------------------
    labor_charge = fields.Monetary(
        string="أجرة العمل", currency_field="currency_id",
        help="أجرة اليد العاملة التي تُحتسب على العميل — تُضاف كسطر في الفاتورة.",
    )
    parts_sale_total = fields.Monetary(
        string="بيع القطع", compute="_compute_sale_totals", store=True,
        currency_field="currency_id",
    )
    quoted_total = fields.Monetary(
        string="إجمالي المطلوب من العميل", compute="_compute_sale_totals", store=True,
        currency_field="currency_id",
    )
    margin_amount = fields.Monetary(
        string="هامش الربح", compute="_compute_sale_totals", store=True,
        currency_field="currency_id",
    )
    invoice_ids = fields.One2many("account.move", "pr_job_card_id", string="الفواتير")
    invoice_count = fields.Integer(string="عدد الفواتير", compute="_compute_invoice_count")

    amount_invoiced = fields.Monetary(
        string="المفوتر", compute="_compute_customer_due",
        currency_field="currency_id",
    )
    amount_paid = fields.Monetary(
        string="المدفوع", compute="_compute_customer_due",
        currency_field="currency_id",
    )
    customer_due = fields.Monetary(
        string="المتبقي على العميل", compute="_compute_customer_due",
        currency_field="currency_id",
        help="لو صدرت فواتير: المتبقي منها. وإلا: إجمالي المطلوب من العميل.",
    )

    # ------------------------------------------------------------------
    # لوحة البطاقة — نسبة الإنجاز، الفني الحالي، الغلاف، علامات التوقف
    # ------------------------------------------------------------------
    progress = fields.Integer(
        string="نسبة الإنجاز", compute="_compute_progress", store=True,
        help="محسوبة من مراحل الأقسام: كل مرحلة معتمدة فنياً تُحتسب كاملة.",
    )
    stages_done = fields.Integer(
        string="مراحل منجزة", compute="_compute_progress", store=True,
    )
    current_stage_id = fields.Many2one(
        "pr.job.stage", string="المرحلة الحالية",
        compute="_compute_current_stage", store=True,
    )
    current_department_id = fields.Many2one(
        "pr.department", string="القسم الحالي",
        related="current_stage_id.department_id", store=True,
    )
    current_technician_id = fields.Many2one(
        "res.users", string="الفني المسؤول",
        related="current_stage_id.technician_id", store=True,
    )
    is_late = fields.Boolean(
        string="تجاوزت الموعد", compute="_compute_deadline",
        search="_search_is_late",
        help="تاريخ التسليم المتوقع مضى والسيارة ما تسلّمت.",
    )
    days_to_deadline = fields.Integer(
        string="الأيام المتبقية", compute="_compute_deadline",
    )
    parts_waiting_count = fields.Integer(
        string="قطع لم تصل", compute="_compute_blocked",
    )
    is_blocked = fields.Boolean(
        string="متوقفة", compute="_compute_blocked", search="_search_is_blocked",
    )
    block_reason = fields.Char(
        string="سبب التوقف", compute="_compute_blocked",
    )
    cover_photo_id = fields.Many2one(
        "pr.job.photo", string="صورة الغلاف",
        domain="[('job_id', '=', id)]", ondelete="set null",
        help="اتركها فارغة وياخذ النظام أحدث صورة (بعد الانتهاء أولاً).",
    )
    cover_image = fields.Image(
        string="الغلاف", compute="_compute_cover_image", store=True,
        max_width=512, max_height=512,
    )

    # ------------------------------------------------------------------
    # مؤشرات الأداء
    # ------------------------------------------------------------------
    lead_time_days = fields.Float(
        string="مدة الإنجاز (يوم)", compute="_compute_kpi", store=True,
        help="من لحظة استلام السيارة إلى تسليمها.",
    )
    delivery_status = fields.Selection(
        [("pending", "لم تُسلَّم"), ("on_time", "في الموعد"), ("late", "متأخرة")],
        string="الالتزام بالموعد", compute="_compute_kpi", store=True, index=True,
    )
    has_rework = fields.Boolean(
        string="فيها إعادة", compute="_compute_rework_count", store=True,
    )

    # ------------------------------------------------------------------
    # قائمة الفحص قبل التسليم
    # ------------------------------------------------------------------
    qc_finish = fields.Boolean(string="التشطيب نظيف وبدون عيوب")
    qc_parts = fields.Boolean(string="القطع المركّبة مطابقة للبطاقة")
    qc_tested = fields.Boolean(string="السيارة مجرّبة ونظيفة")
    qc_photos = fields.Boolean(string="صور ما بعد الانتهاء مرفوعة")
    qc_ready = fields.Boolean(
        string="اكتمل الفحص", compute="_compute_qc_ready", store=True,
    )

    approved_by_id = fields.Many2one(
        "res.users", string="اعتمد التسليم", readonly=True, tracking=True,
    )
    delivered_date = fields.Datetime(string="تاريخ التسليم", readonly=True, tracking=True)
    documenter_id = fields.Many2one(
        "res.users", string="مسؤول التوثيق",
        help="من يدخل بيانات البطاقة والصور والتكاليف في النظام.",
    )
    note = fields.Text(string="ملاحظات")

    # ==================================================================
    @api.model
    def _group_expand_state(self, states, domain):
        """تعرض اللوحة كل المراحل حتى الفارغة — عدا الملغاة."""
        return [s[0] for s in self.STATES if s[0] != "cancel"]

    # ==================================================================
    # Compute
    # ==================================================================
    @api.depends("stage_ids", "photo_ids", "part_ids")
    def _compute_counts(self):
        for card in self:
            card.stage_count = len(card.stage_ids)
            card.photo_count = len(card.photo_ids)
            card.part_count = len(card.part_ids)

    @api.depends("stage_ids.rework")
    def _compute_rework_count(self):
        for card in self:
            card.rework_count = len(card.stage_ids.filtered("rework"))
            card.has_rework = bool(card.rework_count)

    @api.depends("part_ids.sale_subtotal", "part_ids.state", "labor_charge", "total_cost")
    def _compute_sale_totals(self):
        for card in self:
            parts = card.part_ids.filtered(lambda p: p.state not in ("sourcing", "draft", "rejected"))
            card.parts_sale_total = sum(parts.mapped("sale_subtotal"))
            card.quoted_total = card.parts_sale_total + (card.labor_charge or 0.0)
            card.margin_amount = card.quoted_total - card.total_cost

    @api.depends("stage_ids.state", "state")
    def _compute_progress(self):
        weights = {"pending": 0.0, "progress": 0.5, "self_check": 0.8, "approved": 1.0}
        for card in self:
            stages = card.stage_ids
            card.stages_done = len(stages.filtered(lambda s: s.state == "approved"))
            if card.state in ("delivered",):
                card.progress = 100
            elif not stages:
                card.progress = 0
            else:
                total = sum(weights.get(s.state, 0.0) for s in stages)
                card.progress = int(round(100.0 * total / len(stages)))

    @api.depends("stage_ids.state", "stage_ids.sequence")
    def _compute_current_stage(self):
        for card in self:
            ordered = card.stage_ids.sorted(key=lambda s: (s.sequence, s.id))
            active = ordered.filtered(lambda s: s.state in ("progress", "self_check"))
            if not active:
                active = ordered.filtered(lambda s: s.state == "pending")
            card.current_stage_id = active[0] if active else False

    WAITING_PART_STATES = (
        "sourcing", "draft", "mgr_approved", "dir_approved", "ordered", "transit",
    )

    def _search_is_late(self, operator, value):
        today = fields.Date.context_today(self)
        late = [
            "&", "&",
            ("expected_date", "!=", False),
            ("expected_date", "<", today),
            ("state", "not in", ("delivered", "cancel")),
        ]
        return late if _bool_search_positive(operator, value) else ["!"] + late

    def _search_is_blocked(self, operator, value):
        blocked = [("part_ids.state", "in", list(self.WAITING_PART_STATES))]
        return blocked if _bool_search_positive(operator, value) else ["!"] + blocked

    @api.depends("expected_date", "state", "delivered_date")
    def _compute_deadline(self):
        today = fields.Date.context_today(self)
        for card in self:
            if not card.expected_date or card.state in ("delivered", "cancel"):
                card.is_late = False
                card.days_to_deadline = 0
                continue
            delta = (card.expected_date - today).days
            card.days_to_deadline = delta
            card.is_late = delta < 0

    @api.depends("part_ids.state", "stage_ids.state")
    def _compute_blocked(self):
        for card in self:
            waiting = card.part_ids.filtered(
                lambda p: p.state in self.WAITING_PART_STATES
            )
            card.parts_waiting_count = len(waiting)
            reason = False
            if waiting:
                ordered_now = waiting.filtered(
                    lambda p: p.state in ("ordered", "transit")
                )
                reason = (
                    "بانتظار وصول قطع (%s)" % len(waiting)
                    if ordered_now else "قطع بانتظار الاعتماد (%s)" % len(waiting)
                )
            if not reason:
                stuck = card.stage_ids.filtered(
                    lambda s: s.state == "pending" and not s.predecessor_ready
                )
                if stuck:
                    reason = stuck[0].blocking_message or "بانتظار القسم السابق"
            card.block_reason = reason
            card.is_blocked = bool(reason)

    @api.depends("photo_ids", "photo_ids.image", "photo_ids.phase", "cover_photo_id")
    def _compute_cover_image(self):
        rank = {"after": 0, "during": 1, "before": 2, "damage": 3}
        for card in self:
            photo = card.cover_photo_id
            if not photo and card.photo_ids:
                photo = card.photo_ids.sorted(
                    key=lambda p: (rank.get(p.phase, 9), -p.id)
                )[0]
            card.cover_image = photo.image if photo else False

    @api.depends("invoice_ids.state", "invoice_ids.amount_total",
                 "invoice_ids.amount_residual", "quoted_total")
    def _compute_customer_due(self):
        for card in self:
            posted = card.invoice_ids.filtered(lambda m: m.state == "posted")
            card.amount_invoiced = sum(posted.mapped("amount_total"))
            residual = sum(posted.mapped("amount_residual"))
            card.amount_paid = card.amount_invoiced - residual
            card.customer_due = residual if posted else card.quoted_total

    def _compute_invoice_count(self):
        for card in self:
            card.invoice_count = len(card.invoice_ids)

    @api.depends("intake_date", "delivered_date", "expected_date", "state")
    def _compute_kpi(self):
        for card in self:
            if card.intake_date and card.delivered_date:
                delta = card.delivered_date - card.intake_date
                card.lead_time_days = delta.total_seconds() / 86400.0
            else:
                card.lead_time_days = 0.0
            if card.state != "delivered" or not card.delivered_date:
                card.delivery_status = "pending"
            elif not card.expected_date:
                card.delivery_status = "on_time"
            else:
                card.delivery_status = (
                    "late" if card.delivered_date.date() > card.expected_date
                    else "on_time"
                )

    @api.depends(
        "part_ids.subtotal", "part_ids.state",
        "issue_ids.subtotal",
    )
    def _compute_costs(self):
        for card in self:
            parts = card.part_ids.filtered(lambda p: p.state not in ("sourcing", "draft", "rejected"))
            card.parts_cost = sum(parts.mapped("subtotal"))
            card.material_cost = sum(card.issue_ids.mapped("subtotal"))
            card.total_cost = card.parts_cost + card.material_cost

    @api.depends("qc_finish", "qc_parts", "qc_tested", "qc_photos")
    def _compute_qc_ready(self):
        for card in self:
            card.qc_ready = all(
                [card.qc_finish, card.qc_parts, card.qc_tested, card.qc_photos]
            )

    @api.depends("name", "plate_no", "vehicle_make", "vehicle_model")
    def _compute_display_name(self):
        for card in self:
            parts = [card.name or ""]
            vehicle = " ".join(filter(None, [card.vehicle_make, card.vehicle_model]))
            if vehicle:
                parts.append(vehicle)
            if card.plate_no:
                parts.append(f"[{card.plate_no}]")
            card.display_name = " — ".join(p for p in parts if p)

    # ==================================================================
    # CRUD
    # ==================================================================
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", "جديد") == "جديد":
                vals["name"] = self.env["ir.sequence"].next_by_code(
                    "pr.job.card"
                ) or "جديد"
        return super().create(vals_list)

    # ==================================================================
    # الإجراءات
    # ==================================================================
    def action_intake(self):
        """تسجيل استلام السيارة — المشرف الفني فقط."""
        for card in self:
            if card.state != "draft":
                raise UserError("لا يمكن تسجيل الاستلام إلا على بطاقة في حالة مسودة.")
            if not (card.work_requested or "").strip():
                raise UserError(
                    "اكتب تفاصيل العمل المطلوب قبل تسجيل الاستلام.\n"
                    "هذي أهم خانة في البطاقة — بدونها يبدأ الشغل على تفاهم شفهي "
                    "وتصير المشاكل مع العميل."
                )
            card.write({
                "state": "intake",
                "intake_user_id": self.env.user.id,
                "intake_date": fields.Datetime.now(),
            })
            card.message_post(body="تم استلام السيارة وتسجيل تفاصيل العمل المطلوب.")
        return True

    def action_start(self):
        for card in self:
            if card.state != "intake":
                raise UserError("لا يمكن بدء العمل إلا بعد تسجيل الاستلام.")
            if not card.stage_ids:
                raise UserError(
                    "أضف مراحل الأقسام على البطاقة قبل بدء العمل "
                    "(سمكرة، دهان، ميكانيكا... حسب المطلوب)."
                )
            card.state = "progress"
        return True

    def action_quality(self):
        for card in self:
            if card.state != "progress":
                raise UserError("البطاقة ليست قيد العمل.")
            pending = card.stage_ids.filtered(lambda s: s.state != "approved")
            if pending:
                names = "، ".join(pending.mapped("department_id.name"))
                raise UserError(
                    "فيه مراحل ما اعتمدها المشرف الفني بعد: %s" % names
                )
            card.state = "quality"
        return True

    def action_approve(self):
        """اعتماد التسليم — الإدارة التنفيذية."""
        for card in self:
            if card.state != "quality":
                raise UserError("البطاقة ليست تحت الفحص.")
            if not card.qc_ready:
                raise UserError(
                    "أكمل قائمة الفحص قبل التسليم — الأربع نقاط كلها مطلوبة."
                )
            open_parts = card.part_ids.filtered(
                lambda p: p.state in ("draft", "mgr_approved", "dir_approved", "ordered")
            )
            if open_parts:
                raise UserError(
                    "فيه قطع لم تُستلم بعد على هذي البطاقة. "
                    "استلمها أو ألغِها قبل اعتماد التسليم."
                )
            card.write({
                "state": "ready",
                "approved_by_id": self.env.user.id,
            })
        return True

    def action_deliver(self):
        for card in self:
            if card.state != "ready":
                raise UserError("لا يمكن التسليم قبل اعتماد الفحص النهائي.")
            card.write({
                "state": "delivered",
                "delivered_date": fields.Datetime.now(),
            })
            card.message_post(body="تم تسليم السيارة للعميل وإقفال البطاقة.")
        return True

    def action_cancel(self):
        self.write({"state": "cancel"})
        return True

    def action_reset_draft(self):
        self.write({"state": "draft"})
        return True

    # ------------------------------------------------------------------
    # أزرار الإحصاء
    # ------------------------------------------------------------------
    def action_view_photos(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "صور البطاقة",
            "res_model": "pr.job.photo",
            "view_mode": "kanban,list,form",
            "domain": [("job_id", "=", self.id)],
            "context": {"default_job_id": self.id},
        }

    def action_view_parts(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "قطع البطاقة",
            "res_model": "pr.job.part",
            "view_mode": "list,form",
            "domain": [("job_id", "=", self.id)],
            "context": {"default_job_id": self.id},
        }

    # ------------------------------------------------------------------
    # الفوترة — الجسر إلى الفوترة الإلكترونية
    # ------------------------------------------------------------------
    def _prepare_invoice_lines(self):
        """أسطر الفاتورة: القطع بسعر البيع + أجرة العمل."""
        self.ensure_one()
        lines = []
        for part in self.part_ids.filtered(
            lambda p: p.state not in ("sourcing", "draft", "rejected") and p.sale_subtotal
        ):
            vals = {
                "name": part.name,
                "quantity": part.qty,
                "price_unit": part.sale_price,
            }
            if part.product_id:
                vals["product_id"] = part.product_id.id
            lines.append(Command.create(vals))
        if self.labor_charge:
            lines.append(Command.create({
                "name": "أجرة العمل — %s" % (self.name or ""),
                "quantity": 1.0,
                "price_unit": self.labor_charge,
            }))
        return lines

    def action_create_invoice(self):
        """إنشاء فاتورة عميل مسودة من البطاقة."""
        self.ensure_one()
        if self.state not in ("ready", "delivered"):
            raise UserError(
                "لا تُصدر الفاتورة إلا بعد اعتماد الفحص النهائي — "
                "عشان ما نفوتر شغل ما زال مفتوحاً."
            )
        if not self.partner_id:
            raise UserError("حدّد العميل قبل إصدار الفاتورة.")
        lines = self._prepare_invoice_lines()
        if not lines:
            raise UserError(
                "ما فيه ما يُفوتر: أدخل أسعار بيع القطع أو أجرة العمل على البطاقة."
            )
        move = self.env["account.move"].create({
            "move_type": "out_invoice",
            "partner_id": self.partner_id.id,
            "invoice_origin": self.name,
            "pr_job_card_id": self.id,
            "invoice_line_ids": lines,
        })
        self.message_post(body="أُنشئت فاتورة مسودة: %s" % move.name)
        return {
            "type": "ir.actions.act_window",
            "name": "الفاتورة",
            "res_model": "account.move",
            "res_id": move.id,
            "view_mode": "form",
        }

    def action_view_invoices(self):
        self.ensure_one()
        action = {
            "type": "ir.actions.act_window",
            "name": "فواتير البطاقة",
            "res_model": "account.move",
            "domain": [("pr_job_card_id", "=", self.id)],
            "context": {"default_move_type": "out_invoice"},
        }
        if len(self.invoice_ids) == 1:
            action.update({"view_mode": "form", "res_id": self.invoice_ids.id})
        else:
            action["view_mode"] = "list,form"
        return action
