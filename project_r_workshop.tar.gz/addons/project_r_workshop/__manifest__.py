# -*- coding: utf-8 -*-
{
    "name": "Project R — Workshop Operations",
    "summary": "بطاقات عمل الورشة، مراحل الأقسام، القطع والاعتمادات، الصور، وصرف المخزون",
    "description": (
        "نظام تشغيل ورشة بروجكت آر: يغطي دورة السيارة كاملة من دخولها إلى تسليمها. "
        "بطاقة عمل لكل سيارة أو طلبية فيها بيانات العميل والسيارة ووقت الاستلام "
        "وتفاصيل العمل المطلوب؛ مراحل الأقسام (سمكرة، دهان، ميكانيكا، تجهيز) مع "
        "قاعدة إقرار التسليم بين الأقسام؛ القطع بمسار اعتماد على مرحلتين مع تتبّع "
        "حالة الشحنة؛ الصور قبل وأثناء وبعد العمل؛ صرف المواد من عهدة المشرف الفني "
        "مع احتساب التكلفة على السيارة؛ وصلاحيات مفصولة لكل دور."
    ),
    "version": "19.0.2.5.0",
    "category": "Services/Field Service",
    "author": "Project R",
    "website": "https://www.odoo.com",
    "license": "LGPL-3",
    "depends": ["base", "mail", "product", "account"],
    "data": [
        "security/security.xml",
        "security/ir.model.access.csv",
        "data/sequence.xml",
        "data/department_data.xml",
        "data/carrier_data.xml",
        "data/cron_data.xml",
        "views/department_views.xml",
        "views/job_part_views.xml",
        "views/material_issue_views.xml",
        "views/job_card_views.xml",
        "views/parts_board_views.xml",
        "views/tracking_settings_views.xml",
        "views/asset_views.xml",
        "views/routine_task_views.xml",
        "views/dashboard_views.xml",
        "report/job_card_report.xml",
        "views/menus.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "project_r_workshop/static/src/css/workshop_kanban.css",
            "project_r_workshop/static/src/js/job_kanban_kpi.js",
            "project_r_workshop/static/src/xml/job_kanban_kpi.xml",
        ],
    },
    "application": True,
    "installable": True,
}
