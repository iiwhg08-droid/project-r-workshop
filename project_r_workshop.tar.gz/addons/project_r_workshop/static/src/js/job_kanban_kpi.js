/** @odoo-module **/
/**
 * شريط المؤشرات المالية أعلى لوحة السيارات (Kanban).
 *
 * الأرقام تُحسب في الخادم على نفس فلتر البحث المعروض، فتتغيّر تلقائياً
 * كل ما غيّر المستخدم الفلتر أو البحث أو التجميع.
 *
 * الحماية: الخادم هو من يقرر. لو المستخدم ما عنده صلاحية «اطلاع مالي»
 * ترجع الدالة allowed=false بدون أي رقم، فما يقدر يشوفها حتى لو نادى
 * الدالة يدوياً من المتصفح.
 */
import { registry } from "@web/core/registry";
import { kanbanView } from "@web/views/kanban/kanban_view";
import { KanbanController } from "@web/views/kanban/kanban_controller";
import { useService, useBus } from "@web/core/utils/hooks";
import { formatMonetary } from "@web/views/fields/formatters";
import { onWillStart, useState } from "@odoo/owl";

export class PrJobKanbanController extends KanbanController {
    static template = "project_r_workshop.PrJobKanbanView";

    setup() {
        super.setup();
        this.orm = useService("orm");
        this.kpi = useState({
            allowed: false,
            loading: true,
            count: 0,
            contracts: 0,
            paid: 0,
            due: 0,
            labor: 0,
            labor_due: 0,
            parts: 0,
            parts_due: 0,
            scheduled: 0,
            scheduled_count: 0,
            unpaid_profit: 0,
            collected_ratio: 0,
            currency_id: false,
        });
        onWillStart(() => this.loadKpi());
        useBus(this.env.searchModel, "update", () => this.loadKpi());
    }

    async loadKpi() {
        const domain = this.env.searchModel.domain;
        this._kpiToken = (this._kpiToken || 0) + 1;
        const token = this._kpiToken;
        let res;
        try {
            res = await this.orm.call("pr.job.card", "get_kpi_totals", [domain]);
        } catch {
            // ما نكسر الشاشة لو فشل النداء — نخفي الشريط وبس
            res = { allowed: false };
        }
        if (token !== this._kpiToken) {
            return; // وصل رد أحدث
        }
        Object.assign(this.kpi, {
            allowed: false,
            count: 0,
            contracts: 0,
            paid: 0,
            due: 0,
            labor: 0,
            labor_due: 0,
            parts: 0,
            parts_due: 0,
            scheduled: 0,
            scheduled_count: 0,
            unpaid_profit: 0,
            collected_ratio: 0,
        }, res, { loading: false });
    }

    money(value) {
        return formatMonetary(value || 0, {
            currencyId: this.kpi.currency_id,
            digits: [69, 0],
        });
    }

    get kpiCards() {
        const k = this.kpi;
        return [
            // ===== الصف الأول: الصورة الكبيرة =====
            {
                key: "contracts",
                label: "إجمالي العقود",
                value: this.money(k.contracts),
                icon: "fa-file-text-o",
                tone: "neutral",
                sub: k.count + " سيارة",
                hint: "مجموع كل المبالغ المتفق عليها مع العملاء في العرض الحالي",
            },
            {
                key: "paid",
                label: "إجمالي المحصّل",
                value: this.money(k.paid),
                icon: "fa-check-circle-o",
                tone: "good",
                sub: this.collectedPct + "% من العقود",
                hint: "اللي دخل فعلياً من العملاء",
            },
            {
                key: "due",
                label: "إجمالي المتبقي",
                value: this.money(k.due),
                icon: "fa-hourglass-half",
                tone: k.due > 0 ? "warn" : "good",
                sub: "لم يُحصَّل بعد",
                hint: "المستحق للورشة ولم يُحصَّل",
            },
            // ===== الصف الثاني: التفصيل =====
            {
                key: "labor",
                label: "أجور اليد (خدمات)",
                value: this.money(k.labor),
                icon: "fa-wrench",
                tone: "neutral",
                sub: "غير محصّل: " + this.money(k.labor_due),
                hint: "مجموع بنود الخدمات وشغل اليد في العقود",
            },
            {
                key: "parts",
                label: "القطع (منتجات)",
                value: this.money(k.parts),
                icon: "fa-cogs",
                tone: "neutral",
                sub: "غير محصّل: " + this.money(k.parts_due),
                hint: "مجموع بنود القطع والمنتجات المحتسبة على العملاء",
            },
            {
                key: "scheduled",
                label: "عقود مجدولة (بالانتظار)",
                value: this.money(k.scheduled),
                icon: "fa-calendar-check-o",
                tone: k.scheduled > 0 ? "info" : "neutral",
                sub: k.scheduled_count + " سيارة محجوزة",
                hint: "سيارات اتُّفق عليها وأخذت موعد ولم تصل الورشة بعد",
            },
        ];
    }

    get topCards() {
        return this.kpiCards.slice(0, 3);
    }

    get bottomCards() {
        return this.kpiCards.slice(3);
    }

    get collectedPct() {
        return Math.min(100, Math.max(0, Math.round(this.kpi.collected_ratio || 0)));
    }
}

registry.category("views").add("pr_job_kanban", {
    ...kanbanView,
    Controller: PrJobKanbanController,
});
