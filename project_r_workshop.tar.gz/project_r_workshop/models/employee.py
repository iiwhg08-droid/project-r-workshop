# -*- coding: utf-8 -*-
"""الموظفون وسجل الحضور من جهاز البصمة.

الفكرة: لكل موظف بطاقة فيها رقمه في جهاز البصمة، ولكل يوم عمل سجل
حضور فيه وقت الدخول والخروج. النظام يحسب الساعات والتأخير والغياب
تلقائياً حسب دوام الورشة (14:00 إلى 00:00، والجمعة إجازة).
"""
from datetime import datetime, timedelta

from odoo import api, fields, models

ROLES = [
    ("tech", "فني"),
    ("helper", "مساعد"),
    ("painter", "دهان"),
    ("body", "سمكري"),
    ("mechanic", "ميكانيكي"),
    ("office", "إداري"),
    ("media", "إعلامي"),
    ("manager", "إدارة"),
    ("other", "أخرى"),
]

STATUSES = [
    ("present", "حاضر"),
    ("late", "متأخر"),
    ("absent", "غائب"),
    ("rest", "إجازة أسبوعية"),
    ("leave", "إجازة"),
]

# دوام الورشة المعتمد
SHIFT_START = 14.0        # 14:00
SHIFT_END = 24.0          # 00:00 (منتصف الليل — الوردية تعبر اليوم)
GRACE_MINUTES = 10        # سماحية التأخير
REST_WEEKDAY = 4          # الجمعة (0=الإثنين)


class PrEmployee(models.Model):
    _name = "pr.employee"
    _description = "موظف في الورشة"
    _inherit = ["mail.thread"]
    _order = "sequence, id"

    name = fields.Char(string="الاسم", required=True, tracking=True)
    device_name = fields.Char(
        string="الاسم في جهاز البصمة",
        help="الاسم كما هو مكتوب في تقرير الجهاز — يُستخدم لمطابقة السجلات.",
    )
    device_no = fields.Char(string="رقم البصمة", tracking=True)
    sequence = fields.Integer(string="الترتيب", default=10)
    active = fields.Boolean(string="على رأس العمل", default=True, tracking=True)
    role = fields.Selection(ROLES, string="الوظيفة", default="tech", tracking=True)
    department_id = fields.Many2one("pr.department", string="القسم")
    user_id = fields.Many2one("res.users", string="مستخدم النظام")
    phone = fields.Char(string="الجوال")
    start_date = fields.Date(string="تاريخ المباشرة")
    monthly_salary = fields.Monetary(string="الراتب الشهري", tracking=True)
    currency_id = fields.Many2one(
        "res.currency", string="العملة",
        default=lambda self: self.env.company.currency_id,
    )
    company_id = fields.Many2one(
        "res.company", string="الشركة", required=True,
        default=lambda self: self.env.company,
    )
    uses_fingerprint = fields.Boolean(
        string="يبصم", default=True,
        help="ألغِ التحديد لمن لا يستخدم جهاز البصمة (الإدارة مثلاً).",
    )
    note = fields.Text(string="ملاحظات")
    image = fields.Image(string="الصورة", max_width=1024, max_height=1024)

    attendance_ids = fields.One2many(
        "pr.attendance.day", "employee_id", string="سجل الحضور",
    )
    present_days = fields.Integer(string="أيام الحضور", compute="_compute_stats")
    absent_days = fields.Integer(string="أيام الغياب", compute="_compute_stats")
    late_days = fields.Integer(string="أيام التأخير", compute="_compute_stats")
    worked_hours = fields.Float(string="ساعات العمل", compute="_compute_stats")

    _device_no_unique = models.Constraint(
        "UNIQUE(device_no, company_id)",
        "رقم البصمة مستخدم لموظف آخر.",
    )

    @api.depends("attendance_ids.status", "attendance_ids.worked_hours")
    def _compute_stats(self):
        for emp in self:
            att = emp.attendance_ids
            emp.present_days = len(att.filtered(
                lambda a: a.status in ("present", "late")))
            emp.absent_days = len(att.filtered(lambda a: a.status == "absent"))
            emp.late_days = len(att.filtered(lambda a: a.status == "late"))
            emp.worked_hours = sum(att.mapped("worked_hours"))

    def action_open_attendance(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "حضور: %s" % self.name,
            "res_model": "pr.attendance.day",
            "view_mode": "graph,list,form",
            "domain": [("employee_id", "=", self.id)],
            "context": {"default_employee_id": self.id},
        }


class PrAttendanceDay(models.Model):
    _name = "pr.attendance.day"
    _description = "يوم حضور"
    _order = "date desc, employee_id"
    _rec_name = "display_label"

    employee_id = fields.Many2one(
        "pr.employee", string="الموظف", required=True,
        ondelete="cascade", index=True,
    )
    display_label = fields.Char(string="السجل", compute="_compute_display_label")
    date = fields.Date(string="التاريخ", required=True, index=True)
    weekday = fields.Selection(
        [("0", "الإثنين"), ("1", "الثلاثاء"), ("2", "الأربعاء"), ("3", "الخميس"),
         ("4", "الجمعة"), ("5", "السبت"), ("6", "الأحد")],
        string="اليوم", compute="_compute_weekday", store=True,
    )
    month = fields.Char(string="الشهر", compute="_compute_weekday", store=True)
    check_in = fields.Float(string="الدخول", help="بالساعات، مثال 14.25 = 14:15")
    check_out = fields.Float(string="الخروج", help="بعد منتصف الليل يُكتب 24.5 = 00:30")
    worked_hours = fields.Float(
        string="ساعات العمل", compute="_compute_hours", store=True,
    )
    required_hours = fields.Float(
        string="الساعات المطلوبة", compute="_compute_hours", store=True,
    )
    late_minutes = fields.Integer(
        string="دقائق التأخير", compute="_compute_hours", store=True,
    )
    early_leave_minutes = fields.Integer(
        string="دقائق الخروج المبكر", compute="_compute_hours", store=True,
    )
    status = fields.Selection(
        STATUSES, string="الحالة", compute="_compute_hours", store=True,
        group_expand="_group_expand_status",
    )
    department_id = fields.Many2one(
        related="employee_id.department_id", store=True, string="القسم",
    )
    company_id = fields.Many2one(
        related="employee_id.company_id", store=True, string="الشركة",
    )
    source = fields.Char(string="المصدر", default="جهاز البصمة")
    note = fields.Text(string="ملاحظة")

    _day_unique = models.Constraint(
        "UNIQUE(employee_id, date)",
        "فيه سجل حضور لنفس الموظف في نفس اليوم.",
    )

    @api.model
    def _group_expand_status(self, values, domain):
        return [s[0] for s in STATUSES]

    @api.depends("employee_id", "date", "status")
    def _compute_display_label(self):
        for rec in self:
            rec.display_label = "%s — %s" % (
                rec.employee_id.name or "", rec.date or "")

    @api.depends("date")
    def _compute_weekday(self):
        for rec in self:
            if rec.date:
                rec.weekday = str(rec.date.weekday())
                rec.month = rec.date.strftime("%Y-%m")
            else:
                rec.weekday = False
                rec.month = False

    @api.depends("check_in", "check_out", "date")
    def _compute_hours(self):
        for rec in self:
            is_rest = bool(rec.date and rec.date.weekday() == REST_WEEKDAY)
            rec.required_hours = 0.0 if is_rest else (SHIFT_END - SHIFT_START)
            if rec.check_in and rec.check_out:
                rec.worked_hours = max(0.0, rec.check_out - rec.check_in)
            elif rec.check_in or rec.check_out:
                rec.worked_hours = 0.0
            else:
                rec.worked_hours = 0.0

            late = 0
            early = 0
            if rec.check_in:
                late = int(round((rec.check_in - SHIFT_START) * 60))
                late = max(0, late - GRACE_MINUTES)
            if rec.check_out:
                early = max(0, int(round((SHIFT_END - rec.check_out) * 60)))
            rec.late_minutes = late
            rec.early_leave_minutes = early

            if is_rest:
                rec.status = "rest"
            elif not rec.check_in and not rec.check_out:
                rec.status = "absent"
            elif late > 0:
                rec.status = "late"
            else:
                rec.status = "present"
